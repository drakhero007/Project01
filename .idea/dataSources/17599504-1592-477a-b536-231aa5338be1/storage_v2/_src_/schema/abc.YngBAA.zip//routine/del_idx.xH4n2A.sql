create procedure del_idx(IN p_tablename varchar(200), IN p_idxname varchar(200))
  begin  

DECLARE str VARCHAR(250);  

  set @str=concat(' drop index ',p_idxname,' on ',p_tablename);   

    

  select count(*) into @cnt from information_schema.statistics where table_name=p_tablename and index_name=p_idxname ;  

  if @cnt >0 then   

    PREPARE stmt FROM @str;  

    EXECUTE stmt ;  

  end if;  

  

end;

