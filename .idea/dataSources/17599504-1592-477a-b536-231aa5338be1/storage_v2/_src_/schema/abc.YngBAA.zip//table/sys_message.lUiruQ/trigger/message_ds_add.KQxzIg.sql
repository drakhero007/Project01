create trigger message_ds_add
  after INSERT
  on sys_message
  for each row
  begin

-- 	insert into sys_message_ds (message_id,user_id,nr,user_num,tssj) 
-- 	select new.message_id,new.user_id,new.nr,a.user_num,case when new.tssj is null then now() else new.tssj end from sys_user a   where a.user_id=new.user_id;
	
	end;

