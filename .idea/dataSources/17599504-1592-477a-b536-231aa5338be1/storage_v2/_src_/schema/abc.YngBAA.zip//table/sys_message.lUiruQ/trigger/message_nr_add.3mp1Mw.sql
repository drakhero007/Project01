create trigger message_nr_add
  before INSERT
  on sys_message
  for each row
  begin
-- 待审

	
end;

